import logo from './logo.svg';
import './App.css';
import { useSelector, useDispatch } from "react-redux";
import {increment,decrement,login,logout} from './actions/index';
function App() {
  const counter =  useSelector((state)=>state.counter);
  const auth =  useSelector((state)=>state.auth);
  const dispatch =  useDispatch();

  return (
    <>
        {counter}

        <button onClick={()=>dispatch(increment())}>Increase</button>

        <button onClick={()=>dispatch(decrement())}>Decrease</button>
      

        <hr />

        <h2>Login & Logout Functionality</h2>

        <button onClick={()=>dispatch(login())}>Login</button>

        <button onClick={()=>dispatch(logout())}>Logout</button>

        {auth ?(
          <div>You are logged IN</div>
        ):
        (
          <div>You are logged out</div>
        )
        }


        
    </>

  )}




export default App;
